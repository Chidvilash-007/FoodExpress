# 🍔 FoodExpress — React App

Your full HTML+CSS+JS project converted to React!

---

## 📁 Project Structure

```
FoodExpress/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx
    ├── App.jsx              ← All routes defined here
    └── pages/
        ├── Home.jsx         ← Main page (Untitled-1.html)
        ├── Landing.jsx      ← bg.html
        ├── Login.jsx
        ├── Signup.jsx
        ├── ForgotPassword.jsx
        ├── Account.jsx      ← acc.html
        ├── AccountSettings.jsx
        ├── MyOrders.jsx
        ├── SavedAddresses.jsx
        ├── Payment.jsx
        ├── Cart.jsx
        ├── TrackOrder.jsx   ← track.html
        ├── Location.jsx
        ├── BookTable.jsx    ← book.html
        ├── CustomerCare.jsx ← care.html
        ├── Certificates.jsx
        ├── Newsroom.jsx
        ├── Policy.jsx
        └── Terms.jsx
```

---

## 🚀 How to Run

### Step 1 — Install Node.js
Download from: https://nodejs.org (choose LTS version)

### Step 2 — Open terminal in this folder

```bash
cd FoodExpress
```

### Step 3 — Install packages

```bash
npm install
```

### Step 4 — Start the app

```bash
npm run dev
```

Open your browser at **http://localhost:5173**

---

## 🔄 What Changed (HTML → React)

| Old (HTML)              | New (React)                        |
|-------------------------|------------------------------------|
| `href="page.html"`      | `<Link to="/page">`                |
| `onclick="fn()"`        | `onClick={fn}`                     |
| `document.getElementById` | `useState` + `useRef`           |
| `localStorage` in script | Same but inside React functions   |
| CSS checkbox sidebar    | `useState` for `sidebarOpen`       |
| `<script>` slideshow    | `useEffect` + `setInterval`        |
| Local image paths       | Replaced with online image URLs    |

---

## 📝 Notes

- **Local images** (like certificates, newsroom images) — you had local paths like `C:\Users\chidv\Downloads\...`. These are **replaced with online placeholder images**. Add your real images to `public/` folder and update the `src` paths.
- **Video background** (bg.html) — replaced with a CSS gradient background since local video files can't be used directly.
- All `localStorage` logic is preserved exactly as-is.

---

Happy coding! 🎉
